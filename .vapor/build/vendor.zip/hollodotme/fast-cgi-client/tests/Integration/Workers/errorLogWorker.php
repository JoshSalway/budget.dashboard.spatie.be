<?php declare(strict_types=1);

error_log( "ERROR1\n" );
error_log( "ERROR2\n" );
error_log( "ERROR3\n" );
error_log( "ERROR4\n" );
error_log( "ERROR5\n" );
