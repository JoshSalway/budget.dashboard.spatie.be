# Changelog

All notable changes to `laravel-ohdear-webhooks` will be documented in this file

## 1.2.0 - 2019-09-04

- add support for Laravel 6

## 1.1.0 - 2019-02-27

- drop Laravel 5.7 and below
- drop PHP 7.1 and below

## 1.0.5 - 2019-02-27

- add support for Laravel 5.8

## 1.0.4 - 2018-03-08

- fix reading config values

## 1.0.3 - 2018-02-15

- fill in placeholders in config file

## 1.0.2 - 2018-02-08

- add support for L5.6

## 1.0.1 - 2018-01-08

- use `hash_equals` instead of string comparison to determine if the request is valid

## 1.0.0 - 2018-01-08

- initial release
