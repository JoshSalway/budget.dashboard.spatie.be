<?php return array (
  'barryvdh/laravel-ide-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\LaravelIdeHelper\\IdeHelperServiceProvider',
    ),
  ),
  'beyondcode/laravel-dump-server' => 
  array (
    'providers' => 
    array (
      0 => 'BeyondCode\\DumpServer\\DumpServerServiceProvider',
    ),
  ),
  'beyondcode/laravel-websockets' => 
  array (
    'providers' => 
    array (
      0 => 'BeyondCode\\LaravelWebSockets\\WebSocketsServiceProvider',
    ),
    'aliases' => 
    array (
      'WebSocketRouter' => 'BeyondCode\\LaravelWebSockets\\Facades\\WebSocketRouter',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/vapor-core' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Vapor\\VaporServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'ohdearapp/laravel-ohdear-webhooks' => 
  array (
    'providers' => 
    array (
      0 => 'OhDear\\LaravelWebhooks\\OhDearWebhooksServiceProvider',
    ),
  ),
  'spatie/laravel-blade-javascript' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\BladeJavaScript\\BladeJavaScriptServiceProvider',
    ),
  ),
  'spatie/laravel-google-calendar' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\GoogleCalendar\\GoogleCalendarServiceProvider',
    ),
    'aliases' => 
    array (
      'GoogleCalendar' => 'Spatie\\GoogleCalendar\\GoogleCalendarFacade',
    ),
  ),
  'spatie/laravel-tail' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Tail\\TailServiceProvider',
    ),
  ),
  'spatie/laravel-twitter-streaming-api' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelTwitterStreamingApi\\TwitterStreamingApiServiceProvider',
    ),
    'aliases' => 
    array (
      'TwitterStreamingApi' => 'Spatie\\LaravelTwitterStreamingApi\\TwitterStreamingApiFacade',
    ),
  ),
);