<?php return array (
  'App\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\Twitter\\Mentioned' => 
    array (
      0 => 'App\\Services\\TweetHistory\\TweetHistory',
    ),
  ),
);