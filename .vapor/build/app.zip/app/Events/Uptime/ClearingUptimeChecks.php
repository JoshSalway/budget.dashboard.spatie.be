<?php

namespace App\Events\Uptime;

use App\Events\DashboardEvent;

class ClearingUptimeChecks extends DashboardEvent
{
}
