<?php

namespace App\Events\Dashboard;

use App\Events\DashboardEvent;

class Heartbeat extends DashboardEvent
{
}
